#!/usr/bin/env bash
sudo npm i -g sloc
sudo $APT install cloc
