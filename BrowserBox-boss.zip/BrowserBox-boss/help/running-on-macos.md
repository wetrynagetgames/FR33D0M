# To run on Mac

Do:

1. Use Rosetta to open terminal in i386 arch
2. Use nvm to install a node when in this i386 / x64 terminal
3. export TARGET_ARCH=x64 and run npm i (or just use npm run x64i)
4. npm test
