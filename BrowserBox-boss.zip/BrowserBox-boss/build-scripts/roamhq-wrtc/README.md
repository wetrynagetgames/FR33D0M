# Dockerfile for building @roamhq/wrtc targeting Linux/Arm64 on MacOS

The point of this is to attempt to build a wrtc native addon targeting Linux/Arm64, from within a container running on MacOS.


