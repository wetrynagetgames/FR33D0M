/* eslint-disable no-global-assign */
require = require('esm')(module/*, options*/);
module.exports = require('./index.js');
/* eslint-enable no-global-assign */
