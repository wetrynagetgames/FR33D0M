require.context("./docs/7guis/components", true, /.*/);
