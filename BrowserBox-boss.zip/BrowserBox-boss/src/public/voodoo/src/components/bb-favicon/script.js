class BBFavicon extends Base {

}
