class BBBandwidthSpinner extends Base {

}
