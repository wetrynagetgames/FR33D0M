class BBTabs extends Base {

}
