#!/usr/bin/env bash

cp -r node_modules/bang.html/* .bang.html.snapshot/
cp node_modules/simple-peer/simplepeer.min.js src/ 
cp node_modules/lucide-static/icons/*.svg assets/icons/
